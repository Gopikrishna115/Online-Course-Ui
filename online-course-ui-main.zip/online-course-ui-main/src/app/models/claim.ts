export interface Claim{
    claim:string;
    value:string;
    description:string;
  }