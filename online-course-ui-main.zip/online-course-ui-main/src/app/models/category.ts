export interface CourseCategory {
    categoryId: number;
    categoryName: string;
    description: string;
  }
  