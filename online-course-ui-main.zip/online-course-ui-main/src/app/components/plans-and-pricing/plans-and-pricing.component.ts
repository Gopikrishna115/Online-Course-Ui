import { Component } from '@angular/core';

@Component({
  selector: 'app-plans-and-pricing',
  standalone: true,
  imports: [],
  templateUrl: './plans-and-pricing.component.html',
  styleUrl: './plans-and-pricing.component.css'
})
export class PlansAndPricingComponent {

}
